
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyAGRLCHOaBrFOcJTHrjiBr0Nej2nDmQSOY",
    authDomain: "coworker-f8e5e.firebaseapp.com",
    databaseURL: "https://coworker-f8e5e.firebaseio.com",
    storageBucket: "coworker-f8e5e.appspot.com",
  };
  firebase.initializeApp(config);
  console.log('firebase is initialized');
